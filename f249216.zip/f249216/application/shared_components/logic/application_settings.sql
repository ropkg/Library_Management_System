prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 249216
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>49880235317303724379
,p_default_application_id=>249216
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ROHITTEST'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(80452881041700462801)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(80452877515962462798)
,p_version_scn=>15589681146906
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(80452881388469462801)
,p_name=>'ACCESS_CONTROL_SCOPE'
,p_value=>'ACL_ONLY'
,p_is_required=>'N'
,p_valid_values=>'ACL_ONLY, ALL_USERS'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(80452877380758462798)
,p_comments=>'The default access level given to authenticated users who are not in the access control list'
,p_version_scn=>15589681146909
);
wwv_flow_imp.component_end;
end;
/
