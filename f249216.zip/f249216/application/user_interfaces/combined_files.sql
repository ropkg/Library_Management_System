prompt --application/user_interfaces/combined_files
begin
--   Manifest
--     COMBINED FILES: 249216
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>49880235317303724379
,p_default_application_id=>249216
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ROHITTEST'
);
null;
wwv_flow_imp.component_end;
end;
/
